# Standalone PHM data access

PHM-Vibench keeps the existing training contract. The optional
`packages/phm-data-factory` package exposes the same metadata and HDF5 caches to
scripts and local agents without importing PyTorch, task datasets, samplers, or
trainers.

## Install

```bash
pip install -e 'packages/phm-data-factory[excel,yaml,agent,iotdb]'
```

## Use the existing data config

```python
from src.data_factory import build_agent_data_tools

with build_agent_data_tools(args.data) as tools:
    print(tools.repository_summary())
    print(tools.get_sample_metadata("1"))
```

The bridge resolves `data.data_dir`, `data.metadata_file`, and `cache.h5`. If
the consolidated cache does not yet exist, it reads `<Name>.h5` files from the
data directory.

## Run a local MCP server

Create a standalone config that points at the same metadata/cache paths, then:

```bash
phm-data-mcp --config /absolute/path/phm-data.local.yaml
```

The Agent surface is read-only and returns bounded waveform previews. Training
code should use the Python repository directly with `max_points=None` when it
needs complete tensors.

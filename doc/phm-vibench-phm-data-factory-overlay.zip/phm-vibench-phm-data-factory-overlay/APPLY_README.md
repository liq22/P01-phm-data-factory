# PHM-Vibench overlay

Copy this directory over the root of a PHM-Vibench checkout, preserving paths.
It adds `packages/phm-data-factory`, a thin `src.data_factory.standalone`
bridge, Agent dependencies, documentation, and one integration test.

The supplied `src/data_factory/__init__.py` is based on PHM-Vibench `main` at
commit `b7e62c4c97693d058b92b63b5ec6d0b201799a4f`. On a newer revision, prefer
applying `phm-vibench-phm-data-factory-integration.patch` or manually adding the
standalone imports to avoid overwriting unrelated changes.

Install and validate:

```bash
pip install -e 'packages/phm-data-factory[excel,yaml,agent,iotdb]'
PYTHONPATH=. pytest -q packages/phm-data-factory/tests
pytest -q test/test_standalone_data_factory.py
```

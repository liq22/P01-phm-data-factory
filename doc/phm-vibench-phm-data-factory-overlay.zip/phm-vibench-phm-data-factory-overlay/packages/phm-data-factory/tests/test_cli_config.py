from __future__ import annotations

import json
from pathlib import Path

from phm_data_factory.cli import main
from phm_data_factory.config import RepositoryConfig


def test_cli_summary(local_data, capsys):
    metadata, signals = local_data
    code = main(["--metadata", str(metadata), "--signals", str(signals), "summary"])
    assert code == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["samples"] == 2


def test_yaml_config_resolves_relative_paths(local_data, tmp_path: Path):
    metadata, signals = local_data
    config_path = tmp_path / "phm-data.yaml"
    config_path.write_text(
        "backend: local\n"
        f"metadata_path: {metadata.name}\n"
        f"signal_path: {signals.name}\n",
        encoding="utf-8",
    )
    config = RepositoryConfig.from_file(config_path)
    assert config.metadata_path == metadata.resolve()
    assert config.signal_path == signals.resolve()


def test_iotdb_config_can_load_catalog_from_database():
    config = RepositoryConfig.from_mapping(
        {"backend": "iotdb", "iotdb": {"root": "root.test"}}
    )
    assert config.metadata_path is None
    assert config.iotdb["root"] == "root.test"

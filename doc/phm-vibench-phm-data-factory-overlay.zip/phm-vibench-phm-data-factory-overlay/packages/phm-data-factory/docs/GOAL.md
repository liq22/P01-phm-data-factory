# Goal: standalone Agent-ready PHM data layer

## Outcome

Extract PHM metadata and signal access behind a stable package that both
PHM-Vibench training code and local agents can consume, while keeping task
splits, PyTorch datasets, samplers, models, and trainers inside PHM-Vibench.

## Deliverables

1. Installable `phm-data-factory` wheel and source distribution.
2. Metadata + HDF5 repository API keyed by Vibench `Id`.
3. Optional Apache IoTDB import/read backend.
4. Bounded read-only Agent tools and MCP server.
5. Thin PHM-Vibench adapter with no change to `build_data()`.
6. Unit tests and a live-IoTDB smoke-test command.

## Acceptance criteria

- CSV/XLSX metadata is indexed without changing source columns.
- HDF5 keys `Id`, `Id_<Id>`, and `sample_<Id>` are resolved.
- `(L, C)` and `(L, C, 1)` caches produce canonical `(L, C)` windows.
- Agent waveform responses are bounded and report their downsampling step.
- IoTDB import writes aligned channels and mirrors sample metadata.
- Package imports without PyTorch or PHM-Vibench.
- PHM-Vibench continues using its current factory and DataLoader contracts.

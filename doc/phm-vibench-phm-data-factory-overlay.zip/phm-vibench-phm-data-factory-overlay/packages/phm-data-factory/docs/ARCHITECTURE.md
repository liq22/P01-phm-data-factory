# Architecture

```text
metadata.xlsx/CSV -> MetadataCatalog ----+
                                           +-> PHMDataRepository -> PHMbench
HDF5 or IoTDB -----> SignalStore --------+                    -> CLI/MCP Agent
```

The repository returns NumPy arrays. `AgentDataTools` is an anti-corruption
layer that returns JSON-safe bounded results and only accepts exact structured
filters. This prevents Agent runtime requirements from entering training code.
